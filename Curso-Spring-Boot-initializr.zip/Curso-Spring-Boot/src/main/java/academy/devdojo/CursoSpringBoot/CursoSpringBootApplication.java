package academy.devdojo.CursoSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursoSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursoSpringBootApplication.class, args);
	}

}
